import { Text, View } from "react-native";

export default function About() {
  return (
   <View>
    <Text>hello</Text>
   </View>
  )
}

